package com.bezkoder.integrate.spring.react.model;

import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "part")
public class Part {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long partid;


	@Column(name = "partdescription")
	private String partDescription;
	
	@Column(name = "partspecification")
	private String partSpecification;
	
	@Column(name = "stockinhand")
	private String stockInHand;
	public Part() {

	}

	public Part(String title, String description,String phno) {
		this.partDescription = title;
		this.partSpecification = description;
		this.stockInHand = phno;
	}

	public long getPartid() {
		return partid;
	}

	public void setPartid(long partid) {
		this.partid = partid;
	}

	public String getPartDescription() {
		return partDescription;
	}

	public void setPartDescription(String partDescription) {
		this.partDescription = partDescription;
	}

	public String getPartSpecification() {
		return partSpecification;
	}

	public void setPartSpecification(String partSpecification) {
		this.partSpecification = partSpecification;
	}

	public String getStockInHand() {
		return stockInHand;
	}

	public void setStockInHand(String stockInHand) {
		this.stockInHand = stockInHand;
	}
	
	
}
	
