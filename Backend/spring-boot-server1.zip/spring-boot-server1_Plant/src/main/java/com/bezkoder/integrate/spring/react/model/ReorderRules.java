package com.bezkoder.integrate.spring.react.model;
import java.time.LocalDate;

import javax.persistence.*; 
   
@Entity
@Table(name="reorderrules")   
public class ReorderRules {

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Integer rrid;
		
		@Column(name= "demandid")
		private String demandId;
		
		@Column(name= "minquantity")
		private String minQuantity;
		
		@Column(name= "maxquantity")
		private String maxQuantity;
		
		@Column(name= "reorderfrequency")
		private String reorderFrequency;
		
		public ReorderRules()
		{
			
		}
		
		public ReorderRules(String demandId, String minQuantity, String maxQuantity,
				String reorderFrequency) {
			this.demandId = demandId;
			this.minQuantity = minQuantity;
			this.maxQuantity = maxQuantity;
			this.reorderFrequency = reorderFrequency;
		}

		public Integer getRrid() {
			return rrid;
		}

		public void setRrid(Integer rrid) {
			this.rrid = rrid;
		}

		public String getDemandId() {
			return demandId;
		}

		public void setDemandId(String demandId) {
			this.demandId = demandId;
		}

		public String getMinQuantity() {
			return minQuantity;
		}

		public void setMinQuantity(String minQuantity) {
			this.minQuantity = minQuantity;
		}

		public String getMaxQuantity() {
			return maxQuantity;
		}

		public void setMaxQuantity(String maxQuantity) {
			this.maxQuantity = maxQuantity;
		}

		public String getReorderFrequency() {
			return reorderFrequency;
		}

		public void setReorderFrequency(String reorderFrequency) {
			this.reorderFrequency = reorderFrequency;
		}

		

}
