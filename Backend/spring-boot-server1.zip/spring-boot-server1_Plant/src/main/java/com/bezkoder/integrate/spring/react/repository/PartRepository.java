package com.bezkoder.integrate.spring.react.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.bezkoder.integrate.spring.react.model.Part;

public interface PartRepository extends JpaRepository<Part, Long> {
}
