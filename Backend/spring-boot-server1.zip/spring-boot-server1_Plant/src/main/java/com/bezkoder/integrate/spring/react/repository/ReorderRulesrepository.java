package com.bezkoder.integrate.spring.react.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bezkoder.integrate.spring.react.model.ReorderRules;

public interface ReorderRulesrepository extends JpaRepository<ReorderRules,Long> {


}
