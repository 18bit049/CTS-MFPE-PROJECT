package com.bezkoder.integrate.spring.react.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bezkoder.integrate.spring.react.model.ReorderRules;
import com.bezkoder.integrate.spring.react.model.Part;
import com.bezkoder.integrate.spring.react.repository.ReorderRulesrepository;
import com.bezkoder.integrate.spring.react.repository.PartRepository;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class PartController {

	@Autowired
	PartRepository partRepository;
	@Autowired
	ReorderRulesrepository reorderrepo;
	
   
	@GetMapping("/getreorder")
	public ResponseEntity<List<ReorderRules>> getAll() {
		try {
			List<ReorderRules> parts = new ArrayList<ReorderRules>();

				reorderrepo.findAll().forEach(parts::add);

			if (parts.isEmpty()) {
				return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
			}

			return new ResponseEntity<>(parts, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@GetMapping("/getpart")
	public ResponseEntity<List<Part>> getAllTutorials() {
		try {
			List<Part> parts = new ArrayList<Part>();

				partRepository.findAll().forEach(parts::add);

			if (parts.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			return new ResponseEntity<>(parts, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/showpart/{id}")
	public ResponseEntity<ReorderRules> getTutorialById(@PathVariable("id") long id) {
		Optional<ReorderRules> tutorialData = reorderrepo.findById(id);

		if (tutorialData.isPresent()) {
			return new ResponseEntity<>(tutorialData.get(), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/addpart")
	public ResponseEntity<Part> createTutorial(@RequestBody Part part) {
		try {
			Part _tutorial = partRepository.save(new Part(part.getPartDescription(), part.getPartSpecification(), part.getStockInHand()));
			return new ResponseEntity<>(_tutorial, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
		}
	}

	@PutMapping("/showpart/{id}")
	public ResponseEntity<ReorderRules> updateTutorial(@PathVariable("id") long id, @RequestBody ReorderRules tutorial) {
		Optional<ReorderRules> tutorialData = reorderrepo.findById(id);

		if (tutorialData.isPresent()) {
			ReorderRules _tutorial = tutorialData.get();
			_tutorial.setDemandId(tutorial.getDemandId());
			_tutorial.setMinQuantity(tutorial.getMinQuantity());
			_tutorial.setMaxQuantity(tutorial.getMaxQuantity());
			
			return new ResponseEntity<>(reorderrepo.save(_tutorial), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}


	@DeleteMapping("/deletepart")
	public ResponseEntity<HttpStatus> deleteAllTutorials() {
		try {
			partRepository.deleteAll();
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}

	}


}
