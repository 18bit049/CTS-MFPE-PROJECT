
insert into tutorials
values (1,'ramesh','ramesh@gmail.com','9872324423','Andhra',10);
insert into supplier 
values (2,'sam','sam@gmail.com','9876543212','Noida',7);
insert into supplier 
values (3,'deepak','deepak@gmail.com','9738452938','Nasik',9);
insert into supplier 
values (4,'ragul','ragul@gmail.com','9738452938','Andhra',6);

insert into supplier_part 
values (1,1,'Engine',10,7,1);
insert into supplier_part 
values (4,2,'Engine',5,7,3);
insert into supplier_part 
values (2,3,'Tire',10,1,2);
insert into supplier_part 
values (3,3,'Gearbox',10,7,3);



