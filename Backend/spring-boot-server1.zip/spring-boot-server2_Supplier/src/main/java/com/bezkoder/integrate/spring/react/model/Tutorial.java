package com.bezkoder.integrate.spring.react.model;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "tutorials")
public class Tutorial {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "name")
	private String name;

	@Column(name = "email")
	private String email;

	@Column(name = "phno")
	private String phno;
	@Column(name="location")
	private String location;
	@Column(name="feedback")
	private String feedback;
	public Tutorial() {

	}

	public Tutorial(String title, String description,String phno,String loc,String f) {
		this.name = title;
		this.email = description;
		this.phno = phno;
		this.location=loc;
		this.feedback=f;
	}


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhno() {
		return phno;
	}

	public void setPhno(String phno) {
		this.phno = phno;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	public String getFeedback()
	{
		return feedback;
	}
	public void setFeedback(String feedback2) {
		// TODO Auto-generated method stub
		this.feedback=feedback2;
	}

}
	
