package com.bezkoder.integrate.spring.react.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.bezkoder.integrate.spring.react.model.Tutorial;

public interface TutorialRepository extends JpaRepository<Tutorial, Long> {
}
